package F2fExercicise13;

/**
 *
 * @author Deogratias Amani
 * On my honor, as a Carnegie-Mellon Africa student,
 * I have neither given nor received unauthorized assistance on this work.
 *
 * Great Question. I had fun thinking and solving it. Thank you Cathy and Team!!!
 * Have a wonderful Weekend
 * I some codes commented below show my progress to make more readable codes.
 *
 */

public class EvenDigits
{
    public static Boolean isEven(int digit){ return digit%2 == 0;}

    public static void main(String[] args)
    {
        // print numbers with all even digits
        // realized my conditions could still fit in
        // the more readable one below
        // and this way I reduced the number of if statements.
        // Once again I like this question. Thank you!!!!!
        for (int i = 0; i < 200; i++ )
        {
            int middleD = i / 10, firstD = i / 100;
            System.out.print((
                    EvenDigits.isEven(i) &&
                            EvenDigits.isEven(middleD) &&
                            EvenDigits.isEven(firstD)) ? +i + "\n" : "");
        }

//            if ( i < 10)
//                System.out.print((EvenDigits.isEven(i))? +i+"\n" : ""); // print if digit is even
//
//            if ( i > 9 && i < 100) {
//                int lastDigit = i%2, firsDigit = i/10;
//                    System.out.print((
//                            EvenDigits.isEven(lastDigit) &&
//                                    EvenDigits.isEven(firsDigit)) ? +i + "\n" : "");
//            }
//
//            if ( i > 99 && i < 200) {
//                int lastD = i%2, middleD = i/10, firstD = i/100 ;
//                System.out.print((
//                        EvenDigits.isEven(lastD) &&
//                                EvenDigits.isEven(middleD) &&
//                                EvenDigits.isEven(firstD)) ? +i + "\n" : "");
//            }
//        }
        // Thinking how to reduce the if statements...
        // Should turn in something shortly, but I had to first turn this in
        // I like this question.
    }
}
