import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author Deogratias Amani
 * On my honor, as a Carnegie-Mellon Africa student,
 * I have neither given nor received unauthorized assistance on this work.
 *
 */

public class TripMoneyCounter
{
    int tripDuration;
    double dayTot_foodCost;
    double transportCost;
    double hotelCost;
    int nights;

    public TripMoneyCounter()
    {
        this.tripDuration = 0;
        this.dayTot_foodCost = 0;
        this.transportCost = 0;
        this.hotelCost = 0;
        this.nights = 0;
    }



    public TripMoneyCounter(int tripDuration,
                            double dayTot_foodCost,
                            double transportCost,
                            double hotelCost)
    {
        this.tripDuration = tripDuration;
        this.dayTot_foodCost = dayTot_foodCost;
        this.transportCost = transportCost;
        this.hotelCost = hotelCost;
        this.nights = tripDuration - 1;
    }

        public int getTripDuration () {
            return tripDuration;
        }

        public void setTripDuration ( int tripDuration){
            this.tripDuration = tripDuration;
        }

        public double getDayTot_foodCost () {
            return dayTot_foodCost;
        }

        public void setDayTot_foodCost ( double dayTot_foodCost){
            this.dayTot_foodCost = dayTot_foodCost;
        }

        public double getTransportCost () {
            return transportCost;
        }

        public void setTransportCost ( double transportCost){
            this.transportCost = transportCost;
        }

        public double getHotelCost () {
            return hotelCost;
        }

        public void setHotelCost ( double hotelCost){
            this.hotelCost = hotelCost;
        }

        public int getNights () {
            return getTripDuration() - 1;
        }

    public static void main(String[] args) throws IOException {
        BufferedReader userInput =
                new BufferedReader(new InputStreamReader(System.in));

        String  str = "";
        int tripDuration;
        double dayTot_foodCost;
        double transportCost;
        double hotelCost;

        System.out.println("Enter 2 numbers and lets do some math: ");
        System.out.print("Enter first number: ");
        str = userInput.readLine();
        tripDuration = Integer.parseInt(str);
    }
}